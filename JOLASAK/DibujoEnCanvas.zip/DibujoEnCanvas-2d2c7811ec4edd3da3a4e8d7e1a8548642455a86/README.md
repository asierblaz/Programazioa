# DibujoEnCanvas
by: Daniel Escobar Araujo

Apicación en JAva que dibuja en un canvas un Circulo, Rectangulo o Lineas Libres, con la posibilidad de cambiar el color
el grosor de la linea y a su vez un borrador o un boton para empezar de nuevo.

Diseñado en NetBeans IDE 8.2
Para la Materia de Topicos Avanzados de Programación.

Daniel Escobar
(c)Todos Los Derechos Reservados.
