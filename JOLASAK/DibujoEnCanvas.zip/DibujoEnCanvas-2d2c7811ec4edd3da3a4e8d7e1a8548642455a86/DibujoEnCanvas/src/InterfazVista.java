
import javax.swing.JFrame;

public class InterfazVista extends JFrame {

    public static void main(String[] args) {
        Vista drawing = new Vista();
        drawing.setVisible(true);
    }

}
