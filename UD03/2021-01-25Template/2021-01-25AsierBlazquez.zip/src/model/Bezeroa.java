/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author imadariaga
 */
public interface Bezeroa {

     public int getKodea();
     public String getIzena();
     public String getHelbidea();
     public String getEmaila();
}
