CREATE TABLE Terminoak(
id int PRIMARY KEY,
euskaraz VARCHAR(20),
gazteleraz VARCHAR(20))


INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('sagarra', 'manzana');
INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('madaria', 'pera');
INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('marrubia', 'fresa');
INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('baloia', 'balon');
INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('xagua', 'raton');
INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('ordenagailua', 'ordenador');
INSERT INTO "Terminoak" ("euskaraz", "gazteleraz") VALUES ('kalkulagailua', 'calculadora');